package com.doremi.booking.entity;

public enum Role {
    ADMIN,
    USER  
}
