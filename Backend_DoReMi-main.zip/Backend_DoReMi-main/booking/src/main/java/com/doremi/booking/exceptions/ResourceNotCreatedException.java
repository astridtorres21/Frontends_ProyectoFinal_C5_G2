package com.doremi.booking.exceptions;

public class ResourceNotCreatedException extends Exception{

    public ResourceNotCreatedException(String message) {
        super(message);
    }
}
