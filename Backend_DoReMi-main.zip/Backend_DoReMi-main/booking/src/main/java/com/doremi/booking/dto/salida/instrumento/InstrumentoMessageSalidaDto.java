package com.doremi.booking.dto.salida.instrumento;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class InstrumentoMessageSalidaDto {
    public String message;
}
